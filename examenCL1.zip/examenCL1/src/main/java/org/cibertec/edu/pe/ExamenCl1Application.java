package org.cibertec.edu.pe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenCl1Application {

	public static void main(String[] args) {
		SpringApplication.run(ExamenCl1Application.class, args);
	}

}
