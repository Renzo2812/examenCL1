package org.cibertec.edu.pe.controller;

import java.util.List;

import org.cibertec.edu.pe.interfaceService.IEmpleadoService;
import org.cibertec.edu.pe.modelo.Empleado;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EmpleadoController {

	@Autowired
	private IEmpleadoService servicio;
	
	//Método Listar
	@GetMapping("/listar")
	public String Listar(Model m) {
		List<Empleado> LEmpleado = servicio.Listado();
		m.addAttribute("lista", LEmpleado);
		
		int cantidad = LEmpleado.size();
		m.addAttribute("cantidad", cantidad);
		return "listar";
	}
	
	//Método agregar
	@GetMapping("/registrar")
	public String agregar() {
		return "registrar";
	}
	
	//Método grabar
	@GetMapping("/grabar")
	public String guardar(Empleado a, Model m) {
		servicio.grabar(a);
		return "redirect:/listar";
	}
	
}
